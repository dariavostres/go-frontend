# Изучение блочной верстки
### HTML/CSS (position)
Выполните верстку макета используя свойство position:absolute. Материалы для верстки находятся в папке assets.


![](https://raw.githubusercontent.com/luschenko/water_world_div/master/result.png)
		
